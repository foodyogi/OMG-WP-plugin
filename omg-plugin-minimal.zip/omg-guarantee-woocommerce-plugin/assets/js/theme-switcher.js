/**
 * OM Guarantee Theme Switcher
 * Allows toggling between light and dark themes for OMG widgets
 */

(function() {
    // Initialize theme on document ready
    document.addEventListener('DOMContentLoaded', function() {
        // Look for theme preference in local storage
        const savedTheme = localStorage.getItem('omg_theme_preference');
        if (savedTheme === 'dark') {
            applyDarkTheme();
        }

        // Add theme toggle buttons
        addThemeToggleButtons();
    });

    // Apply dark theme to all OMG widgets
    function applyDarkTheme() {
        const widgets = document.querySelectorAll('.omg-impact-dashboard-compact, .omg-impact-summary, .omg-donation-counter, .omg-charity-list, .omg-certification-badge-compact');
        
        widgets.forEach(widget => {
            widget.classList.remove('omg-light-theme');
            widget.classList.add('omg-dark-theme');
        });

        localStorage.setItem('omg_theme_preference', 'dark');
    }

    // Apply light theme to all OMG widgets
    function applyLightTheme() {
        const widgets = document.querySelectorAll('.omg-impact-dashboard-compact, .omg-impact-summary, .omg-donation-counter, .omg-charity-list, .omg-certification-badge-compact');
        
        widgets.forEach(widget => {
            widget.classList.remove('omg-dark-theme');
            widget.classList.add('omg-light-theme');
        });

        localStorage.setItem('omg_theme_preference', 'light');
    }

    // Add theme toggle buttons to widgets
    function addThemeToggleButtons() {
        const widgets = document.querySelectorAll('.omg-impact-dashboard-compact, .omg-impact-summary, .omg-donation-counter, .omg-charity-list, .omg-certification-badge-compact');
        
        widgets.forEach(widget => {
            // Create toggle button
            const toggleButton = document.createElement('button');
            toggleButton.className = 'omg-theme-toggle';
            toggleButton.setAttribute('aria-label', 'Toggle dark/light mode');
            toggleButton.innerHTML = widget.classList.contains('omg-dark-theme') ? '☀️' : '🌙';
            
            // Add CSS for button
            toggleButton.style.position = 'absolute';
            toggleButton.style.top = '10px';
            toggleButton.style.right = '10px';
            toggleButton.style.background = 'transparent';
            toggleButton.style.border = 'none';
            toggleButton.style.fontSize = '16px';
            toggleButton.style.cursor = 'pointer';
            toggleButton.style.padding = '5px';
            toggleButton.style.borderRadius = '50%';
            toggleButton.style.width = '30px';
            toggleButton.style.height = '30px';
            toggleButton.style.display = 'flex';
            toggleButton.style.alignItems = 'center';
            toggleButton.style.justifyContent = 'center';
            toggleButton.style.opacity = '0.7';
            toggleButton.style.transition = 'opacity 0.3s ease';
            
            toggleButton.onmouseover = function() {
                this.style.opacity = '1';
            };
            
            toggleButton.onmouseout = function() {
                this.style.opacity = '0.7';
            };

            // Make sure the widget has position relative for absolute positioning
            const currentPosition = window.getComputedStyle(widget).position;
            if (currentPosition !== 'absolute' && currentPosition !== 'relative' && currentPosition !== 'fixed') {
                widget.style.position = 'relative';
            }
            
            // Add click event
            toggleButton.addEventListener('click', function() {
                if (widget.classList.contains('omg-dark-theme')) {
                    applyLightTheme();
                    this.innerHTML = '🌙';
                } else {
                    applyDarkTheme();
                    this.innerHTML = '☀️';
                }
            });
            
            // Add button to widget
            widget.appendChild(toggleButton);
        });
    }
})();